/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classtest;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class ClassTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
//  Question # 1  
        
       System.out.println("\tQuestion 1\n");
        
       int x;
        System.out.println("enter any integer number");
        x = sc.nextInt();
        if(x>=0){ 
            System.out.println(x + " is positive");
        }
        else{
            System.out.println(x + " is negative");
        }
    
//  Question # 2

        System.out.println("\n\tQuestion 2\n");
        int value1, value2, value3;
        double root1, root2, d;
        Scanner s = new Scanner(System.in);
        System.out.println("Given quadratic equation:ax^2 + bx + c");
        System.out.print("Enter value1:");
        value1 = s.nextInt();
        System.out.print("Enter value2:");
        value2 = s.nextInt();
        System.out.print("Enter value3:");
        value3 = s.nextInt();
        System.out.println("Given quadratic equation:"+value1+"x^2 + "+value2+"x + "+value3);
        d = value2 * value2 - 4 * value1 * value3;
        if(d > 0)
        {
            System.out.println("Roots are real and unequal");
            root1 = ( - value2 + Math.sqrt(d))/(2*value1);
            root2 = (-value2 - Math.sqrt(d))/(2*value1);
            System.out.println("First root is:"+root1);
            System.out.println("Second root is:"+root2);
        }
        else if(d == 0)
        {
            System.out.println("Roots are real and equal");
            root1 = (-value2+Math.sqrt(d))/(2*value1);
            System.out.println("Root:"+root1);
        }
        else
        {
            System.out.println("Roots are imaginary");
        }

        
        
        
//  Question # 3
        
        System.out.println("\n\tQuestion 3\n");
              
        int a,b,c;
        System.out.println("Enter number 1");
        a= sc.nextInt();
        System.out.println("Enter number 2");
        b= sc.nextInt();
        System.out.println("Enter number 3");
        c= sc.nextInt();        
        if(a>b && a>c){
            System.out.println(a + " this is the greater");
        }
        else if(b>a && b>c){
           System.out.println(b + " this is the greater");
        }        
        else if(c>a && c>b){
           System.out.println(c + " this is the greater");
        }

        
//  Question # 4
        
        System.out.println("\n\tQuestion 4\n");
        
        double floating_point;
        
        System.out.println("enter the float value");
        floating_point = sc.nextDouble();
        
        if (floating_point==0) {
            System.out.println("zero");
        }
        else if (floating_point<0) {
            System.out.println("nagetive number");
        } 
        else if (floating_point<1) {
            System.out.println("small , positive number");
        }
        else if (floating_point>1000000) {
            System.out.println("large , positive number");
        }else{
            System.out.println("positive number");
        }
        
       

//  Question # 5
        
        System.out.println("\n\tQuestion 5\n");
        
        int w;
        System.out.print("Enter date to get weekday = ");
        w = sc.nextInt();
        if(w>7){
            w= w/7;
        switch(w){
            case 1:
                System.out.println("Monday");
                break;        
            case 2:
                System.out.println("tuesday");
                break;               
            case 3:
                System.out.println("wednesday");
                break;               
            case 4:
                System.out.println("thursday");
                break;               
            case 5:
                System.out.println("friday");
                break;                
            case 6:
                System.out.println("saturday");
                break;                
            case 7:
                System.out.println("chutti / sunday");
                break;            
            default:
                System.out.println("wrong input");        
        }      
        }
        else{        
         switch(w){
            case 1:
                System.out.println("Monday");
                break;                
            case 2:
                System.out.println("tuesday");
                break;               
            case 3:
                System.out.println("wednesday");
                break;              
            case 4:
                System.out.println("thursday");
                break;               
            case 5:
                System.out.println("friday");
                break;               
            case 6:
                System.out.println("saturday");
                break;                
            case 7:
                System.out.println("chutti / sunday");
                break;            
            default:
                System.out.println("wrong input");        
        }      
        }
        
//  Question # 6        

        System.out.println("\n\tQuestion 6\n");
        
        double num1,num2; 
 
        System.out.print("enter first floating­point number: "); 
        num1 = sc.nextDouble(); 
        System.out.print("enter second floating­point number: "); 
        num2 = sc.nextDouble();
  
        if (Math.abs(num1 - num2) <= 0.01) { 
            System.out.println("These numbers are the same."); 
        } 
        else { 
            System.out.println("These numbers are different."); 
        } 

        
//  Question # 7 
        
        System.out.println("\n\tQuestion 7\n");
        
        int month;
        int year;
        System.out.println("enter the number of month");
        month = sc.nextInt();
        System.out.println("enter the year");
        year = sc.nextInt();
        
        if (month== 2 && year%4==0) {
            System.out.println("february"+year+"has"+"29 days");
        }
        else{
            switch (month) {
                case 1:
                    System.out.println("januray "+year+" has 31 days");
                    break;
                case 2:
                    System.out.println("february "+year+" has 28 days");
                    break; 
                case 3:
                    System.out.println("march "+year+" has 31 days");
                    break;
                case 4:
                    System.out.println("april "+year+" has 30 days");
                    break;
                case 5:
                    System.out.println("may "+year+" has 31 days");
                    break;
                case 6:
                    System.out.println("june "+year+" has 30 days");
                    break;
                case 7:
                    System.out.println("july "+year+" has 31 days");
                    break; 
                case 8:
                    System.out.println("august "+year+" has 31 days");
                    break;
                case 9:
                    System.out.println("september "+year+" has 30 days");
                    break;
                case 10:
                    System.out.println("octuber "+year+" has 31 days");
                    break;
                case 11:
                    System.out.println("november "+year+" has 30 days");
                    break;
                case 12:
                    System.out.println("december "+year+" has 31 days");
                    break;
                default:
                    System.err.println("something is wrong");
            }
        }
        
//  Question # 8
        
        System.out.println("\n\tQuestion 8\n");
        
        String alp;       
        System.out.println("enter the alphabet");
        alp= sc.next();
        if(alp.length()==1){
            switch (alp) {
                case "a":
                case "A":
                case "e":
                case "E": 
                case "i":
                case "I":
                case "o":
                case "O":
                case "u":
                case "U":
                    System.out.println(alp+" is a vowel");
                    break;
                default:
                    System.out.println(alp+" is a consonant");
            }
        }
        else{
            System.out.println("error");
        }
  
//  Question # 9
        
        System.out.println("\n \tQuestion 9\n");
        
        int Year;        
        System.out.println("enter the year");
        Year = sc.nextInt();
        if (Year%4==0) {
            System.out.println(Year+" is a leap year");
        }else{
            System.out.println(Year+" is not a leap year");
        }
        
        
    }
    
}
