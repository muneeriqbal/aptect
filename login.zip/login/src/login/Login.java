/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Login {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("enter your name");
        
        String name = sc.next();
        
       
            if ("admin".equals(name)) {
               
                System.out.println("enter your pswd ");
                String psw = sc.next();
                if ("123".equals(psw)) {
                       
                         System.out.println("login");
                    
                }else{
                     
                         for (int a = 1; a < 6; a++) {
            
                             System.out.println("enter your pswd ");
                
                             psw = sc.next();
                         
                             
                             
                              if ("123".equals(psw)){
                                  System.out.println("aaaaaahhhhhhhhhhhhhh");
                                  System.out.println("login");
                                  System.exit(a);
                              }
                              else{
                                  System.out.println("error");
                              
                              }
                     }
                     
                     
                     }
               
            }else{
                 for (int i = 1; i < 6; i++) {
                    System.out.println("enter your name");
                    name =sc.next();
                 
                     if ("admin".equals(name)) {
                          
                          System.out.println("asasasasasasasas");
                          
                          System.out.println("enter your pswd ");
                          String psw = sc.next();
                        
                          if ("123".equals(psw)) {
                              System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaa");
                         System.out.println("login");
                         
                         
                     } else{
                     
                         for (int a = 1; a < 6; a++) {
            
                             System.out.println("enter your pswd ");
                
                             psw = sc.next();
                         
                             
                             
                              if ("123".equals(psw)){
                                  System.out.println("aaaaaahhhhhhhhhhhhhh");
                                  System.out.println("login");
                                  System.exit(a);
                              }
                              else{
                                  System.out.println("error");
                              
                              }
                     }
                     
                     
                     }
                     
                     
               
                 
                    
                
                 }
      //    System.exit(i);
                 }
            
        
        
    }
    
    }}

