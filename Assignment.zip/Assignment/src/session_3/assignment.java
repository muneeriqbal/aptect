/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_3;

import java.util.Scanner;

/**
 *
 * @author abbasi
 */
public class assignment {
    
    public static void main(String[] args) {
        
        
            Scanner sc = new Scanner(System.in);
        
//////     question 2             
         
        int deposit;
          
        System.out.println("Enter the deposit amount");
        
        deposit = sc.nextInt();
        int interest = 5;      
            float earning = (float)deposit/100*interest;
            
            System.out.println("interest earned is "+earning+"rs");

           System.out.println();
           System.out.println();

//////     question 3 
           
        int first,second,bitwise;
         
            System.out.println("Enter first number ");
            first = sc.nextInt();
          
            System.out.println("\nEnter second number ");
            second = sc.nextInt();
           
            System.out.println("select any condition "); 
            System.out.println(" press 1, number & number2 ");
            System.out.println(" press 2, number | number2 ");
            System.out.println(" press 3, ~ number1 ");
            System.out.println(" press 4, ~ number2 ");
            System.out.println(" press 5, ( ~ number1)  & (~n umber2) ");
            System.out.println(" press 6, ( ~ number1)  | (~n umber2) ");
            System.out.println(" press 7, number1 >> number2 ");
            System.out.println(" press 8, number1 << number2 ");
            System.out.println(" press 9, number2 >> number1 ");
            System.out.println(" press 9, number2 << number1 ");

            String operator = sc.next();
            switch(operator) {
            
                case "1":
                  bitwise = first & second ;
                  System.out.println(bitwise);
                  break;
                case "2":
                  bitwise = first | second ;
                  System.out.println(bitwise);
                  break;
                case "3":
                  bitwise = ~first ;
                  System.out.println(bitwise);
                  break;
                case "4":
                  bitwise = ~second ;
                  System.out.println(bitwise);
                  break;
                case "5":
                  bitwise = (~first) & (~second) ;
                  System.out.println(bitwise);
                  break;
                case "6":
                  bitwise = (~first) & (~second) ;
                  System.out.println(bitwise);
                  break;
                case "7":
                  bitwise = first >> second ;
                  System.out.println(bitwise);
                  break;
                case "8":
                  bitwise = first << second ;
                  System.out.println(bitwise);
                  break;
                case "9":
                  bitwise = second << first ;
                  System.out.println(bitwise);
                  break;
                case "10":
                  bitwise = second << first ;
                  System.out.println(bitwise);
                  break;
        }
 
        
        
        
        
        
    
      
      
    
    }
}
