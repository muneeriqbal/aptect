/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_3;

/**
 *
 * @author abbasi
 */
public class Format_Specifier {
    
    
    public static void main(String[] fs){
        
        
        int a = 20 / 3;
        
        System.out.printf("20/3=%d %n",a);
        
        double b = 25 / 2;
        
        System.out.printf("25/2=%.3f %n",b);
         
        double c = 30 / 4;
        
        System.out.printf("30/4=%e %n",c);
        
        double d = -10.0 / 0.0;
        
        System.out.printf("-10.0/0.0 = %7.2e %n", d);
    }
    
    
}
