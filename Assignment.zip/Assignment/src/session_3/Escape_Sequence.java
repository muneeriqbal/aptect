/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_3;

/**
 *
 * @author abbasi
 */
public class Escape_Sequence {
    
    public static void main(String[] es) {

        System.out.println("Java \t Programming  Language\n");

        System.out.println("hello \"java\" world \n");
        
        System.out.println("this \ris a \'escape sequences\' assignment \b of session 3 ");
        
        
        System.out.println("\u0048\u0065\u006C\u006C\u006f" + "!\n");
        
        System.out.println("Bl\141ke\"2007\" ");
}

    
  
    
}
