/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example_session8;

/**
 *
 * @author abbasi
 */
public class Two_Dimenssion_array {
    //Declare a two-dimensional array named marks
    int marks[][]; //line 1
    /**
    * Stores marks in a two-dimensional array
    *
    * @return void
    */
    public void storeMarks() {
        // Instantiate the array
        marks = new int[4][2]; // line 2
        System.out.println("Storing Marks. Please wait...");
        // Initialize array elements
        marks[0][0] = 23; // line 3
        marks[0][1] = 65;
        marks[1][0] = 42;
        marks[1][1] = 47;
        marks[2][0] = 60;
        marks[2][1] = 75;
        marks[3][0] = 75;
        marks[3][1] = 50;
    }
    /**
    * Displays marks from a two-dimensional array
    *
    * @return void
    */
    public void displayMarks() {
        System.out.println("Marks are:");
        // Display the marks
//        System.out.println("Roll no.1:" + marks[0][0]+ "," + marks[0][1]);
//        System.out.println("Roll no.2:" + marks[1][0]+ "," + marks[1][1]);
//        System.out.println("Roll no.3:" + marks[2][0]+ "," + marks[2][1]);
//        System.out.println("Roll no.4:" + marks[3][0]+ "," + marks[3][1]);
//        
        
        
        for (int row = 0; row < marks.length; row++) {
            System.out.println("Roll no." + (row+1));
            // inner loop
            for (int col = 0; col < marks[row].length; col++) {
            System.out.println(marks[row][col]);
            }
        }
    
    }
    /**
    * @param args the command line arguments
    */
    public static void main(String[] args) {
        //Instantiate class TwoDimension
        Two_Dimenssion_array Obj = new Two_Dimenssion_array(); // line 4
        //Invoke the storeMarks() method
        Obj.storeMarks();
        //Invoke the displayMarks() method
        Obj.displayMarks();
    }
}
