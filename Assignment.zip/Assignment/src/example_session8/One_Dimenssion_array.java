/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example_session8;

/**
 *
 * @author abbasi
 */
public class One_Dimenssion_array {
    //Declare a single-dimensional array named marks
    int marks [] = new int[5];                                        // line 1
    /**
    * Instantiates and initializes a single-dimensional array
    *
    */
    public void storeMarks(int marks0,int marks1,int marks2,int marks3,int marks4) {
        // Instantiate the array
       // marks = new int[4];                                         // line 2
        System.out.println("Storing Marks. Please wait...");
        // Initialize array elements    
        marks[0] = marks0;          // marks[0] = 10;                 // line 3
        marks[1] = marks1;          // marks[1] = 11;
        marks[2] = marks2;          // marks[2] = 15;
        marks[3] = marks3;          // marks[3] = 20;
        marks[4] = marks4;          // marks[4] = 25;
    }
    /**
    * Displays marks from a single-dimensional array
    *
    */
//    public void displayMarks() {
//        System.out.println("Marks are:");
//        // Display the marks
//        System.out.println(marks[0]);
//        System.out.println(marks[1]);
//        System.out.println(marks[2]);
//        System.out.println(marks[3]);
//    }
    
    public void displayMarks() {
        System.out.println("Marks are:");
        // Display the marks using for loop
        for(int count = 0; count < marks.length; count++) {
        System.out.println(marks[count]);
        }
    
    }
    /**
    * @param args the command line arguments
    */
    public static void main(String[] args) {
        //Instantiate class OneDimension
        One_Dimenssion_array Obj = new One_Dimenssion_array();        // line 4
        //Invoke the storeMarks() method
        Obj.storeMarks(10,11,15,20,1);                                  // line 5
        //Invoke the displayMarks() method
        Obj.displayMarks();                                           // line 6
    }
}
