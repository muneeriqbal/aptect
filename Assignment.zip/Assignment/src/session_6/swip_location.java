/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_6;

/**
 *
 * @author abbasi
 */
public class swip_location {
    
    public static void main(String[] args) {
    
        int num1= 10;
        int num2 = 20;
          
        System.out.println(num1 + "  " + num2 );
          
        num2 = num2-num1;  
        num1 = num1+num2;
        
        System.out.println(num1 + "  " + num2 );
        
    }
}
