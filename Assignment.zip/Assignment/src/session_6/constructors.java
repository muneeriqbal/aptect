/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_6;

/**
 *
 * @author abbasi
 */
public class constructors {
     
    int width ;
    int height;
    String str;
    
    {
        System.out.println("Start");
    }
    
    
    constructors() {
        System.out.println("Constructor invoked..");
        width = 10;
        height = 20;
        str= "abc";
    }
     
    {
        System.out.println("muneer");
    }

    constructors(int wid, int heig, String a) {
        System.out.println("Parameterized Constructor");
        width = wid;
        height = heig;
        str = a;
    }
    
    void displayDimensions(){
        System.out.println("Width: " + width);
        System.out.println("Height: " + height);
        System.out.println("string: "+ str);
    }
     
    public static void main(String[] args) {
        
        constructors objRec = new constructors();

        // Accesses the instance variables using the object reference
        
        objRec.displayDimensions();
    }
}
