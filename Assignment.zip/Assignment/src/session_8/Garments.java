/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_8;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author abbasi
 */
public class Garments {
     ArrayList type = new ArrayList();
    int i,a,id,stock,price,sales,quantity;
    //String [] type = new String[6];
    //String type;
    Scanner sc = new Scanner(System.in);

    public Garments(int stock, int price, int sales, int quantity) {
        
        this.stock = stock=100;
        this.price = price;
        this.sales = sales;
        this.quantity = quantity;
    }
    
    void addgarments(){    
        
        
      
        
//        System.out.println("");
//        String a = sc.next();
        
        type.add("suit");
        type.add("suit");
        
       
        for (i = 0; i <type.size(); i++) {
            
          type.get(i);
           
        }
         
    for (a = 0; a <= i ; a++) {
            id = a;
        }
    
    }
    void showdetial(){
        System.out.println(type+""+ id );
   
    }
    
    public static void main(String[] args) {
        
        Garments obj = new Garments(2, 100, 100, 1);
        obj.addgarments();
        obj.showdetial();
    }
}
