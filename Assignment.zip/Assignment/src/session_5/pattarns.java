/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_5;

import java.util.Scanner;

/**
 *
 * @author abbasi
 */
public class pattarns {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the number,which size pattern you want");
        int user = sc.nextInt();
  
        /* pattern 1
        *
        *    1
        *    12
        *    123
        *    1234
        *    12345
        */
        System.out.println("pattern 1\n");
        
        for (int i = 1; i < user; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j);
            }
            System.out.println("");
        }

        /* pattern 2
        *
        *         
        *        *
        *       **
        *      ***
        *     ****
        */
        System.out.println("\n\npattern 2\n");
        
        for (int i = 1; i < user; i++) {
            for (int j = user; j >= i; j--) {
                System.out.print(" ");
            }
            for (int k = 1; k < i; k++) {
                    System.out.print("*");
                }
            System.out.println("");
        }
        
        /* pattern 3
        *
        *   *****    
        *    ****
        *     ***
        *      **
        *       *
        */
        System.out.println("\n\npattern 3\n");
        
        for (int i = 1; i < user; i++) {
            for (int j = 1; j <i; j++) {
                System.out.print(" "); 
            }
            for (int k = user; k > i; k--) {
                System.out.print("*");
            }
            System.out.println("");
        }
        
        /* pattern 4
        *
        *   *****    
        *   ****
        *   ***
        *   **
        *   *
        */
        System.out.println("\n\npattern 4\n");
        
        for (int i = 1; i < user; i++) {
            for (int k = user; k > i; k--) {
                System.out.print("*");
            }
            System.out.println("");
        }
        
         /* pattern 5
        *
        *       *
        *      ***
        *     *****
        *    *******
        *   *********
        */
        System.out.println("\n\npattern 5\n");
        
        for (int i = 1; i < user; i++) {
            for (int j = i; j < user ; j++) {
                System.out.print(" ");
            }
            for (int k = 1; k < (i*2); k++) {
                System.out.print("*");
            }
            System.out.println("");
        }
        
        
         /* pattern 6
        *
        *       *
        *      ***
        *     *****
        *    *******
        *   *********
        *    *******
        *     *****  
        *      *** 
        *       *
        */
        System.out.println("\n\npattern 6\n");
        
        for (int i = 1; i <= user; i++) {
            for (int j = user; j > i; j--) {
                System.out.print(" ");
            }
            for (int k = 1; k < (i+i); k++) {
                    System.out.print(k);
                }
            System.out.println("");
        }
        for (int a =1 ; a <= user; a++) {
            for (int b = 1; b <= a; b++) {
                System.out.print(" ");
            }
            for (int c = (user*2-1); c > (a+a); c--) {
                System.out.print(c);
            }
            System.out.println("");
        }
        
        
        
  
        
        
    }
    
}
    
        
