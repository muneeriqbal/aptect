/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_5;

import java.util.Scanner;



/**
 *
 * @author abbasi
 */
public class table_user_input {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("enter the starting table's number");
        int table_start = sc.nextInt();
        System.out.println("enter the ending table's number");
        int table_ending = sc.nextInt();
        System.out.println("enter length, wehre you end the table");
        int ending_No = sc.nextInt();
        
        
        for (int j = table_start ; j <= table_ending; j++) {
            
            
            System.err.println("table of \""+j+"\"\n");
            
    
            for (int i = 1; i <= ending_No; i++) {
            
                int answer = j * i;
            
                System.out.println(j + "*" + i + "=" + answer);
            
            }
            System.out.println(" \n\n");
        }
    }
    
}
