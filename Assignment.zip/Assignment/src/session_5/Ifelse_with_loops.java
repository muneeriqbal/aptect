/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_5;

import java.util.Scanner;

/**
 *
 * @author abbasi
 */
public class Ifelse_with_loops {
     public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a =1;
        while (a<6) {  
            System.out.println("enter your name");
            String name = sc.next();
            if ("admin".equals(name)) {
                System.out.println("enter your password");
                String pswd = sc.next();
                if ("123".equals(pswd)) {
                    System.out.println("welcome");
                    System.exit(a);
                } else {
                    int b=1;
                    while (b<6) {                        
                        System.out.println("enter your correct password");
                        pswd = sc.next();
                        if ("123".equals(pswd)) {
                            System.out.println("welcome");
                            System.exit(a);
                        }
                        b++;
                    }
                    System.exit(a);
                }
            } else {
                System.out.println("invalid name");
            }
        a++;
        }
    }
}
