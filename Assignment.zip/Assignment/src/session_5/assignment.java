/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_5;

import java.util.Scanner;

/**
 *
 * @author abbasi
 */
public class assignment {
    public static void main(String[] s5) {
        int attempt,ans,score=0;
        String all,exit;
        Scanner sc = new Scanner(System.in);
        
        
        System.out.println("WELCOME TO HOWELL UNIVERSITY FOR IQ TEST");
        System.err.println("WE HAVE FOUR KIND OF TEST FOR IQ:\t 1. APPTITUDE \t 2.ENGLISH \t 3. MATHS \t 4.GK");
        System.out.println("PRESS A.CONTINUE & PRESS 0.EXIT");
        exit =sc.next();
        switch (exit){
            case "a":
                System.err.println("YOU WANT TO TEST ALL OF THEM: \"YES\" OR \"NO\"");
                all = sc.next();
                switch(all){
                    case "yes":
////1ST                
                        System.err.println("1. APPTITUDE");
                        
                        System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 5 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
////2ND                
                        System.err.println("2. ENGLISH");
                        
                        System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 5 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
////3ND 
                        System.err.println("3. MATHS");
                        
                        System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 5 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
////4ND          
                        System.err.println("4. GK");
                        
                        System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }
                        System.out.println("question 5 \n \t (1).TRUE \t (2).FALSE");
                        ans = sc.nextInt();
                        if (ans==1) {
                            score = score + 2;
                        } else {
                            score = score + 0;
                        }

                        System.err.println("YOUR TEST HAS BEEN COMPLETE.");
                        
                        System.out.println("NOW, PRESS 0. FOR EXIT & GETS YOUR RESULT");
                        attempt =sc.nextInt();
                        if (attempt==0) {
                            
                            if(score>=40){
                                            score = score + 10;
                                            System.err.println("your total score = "+score+"\n\t\"YOU ARE A GENIUS\"");
                                    }else if(score>=30){   
                                            score = score + 8;
                                            System.err.println("your total score = "+score+"\n\t\"YOU ARE INTELLIGENT\"");
                                    }else if(score>=20){   
                                            score = score + 5;
                                            System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS AVERAGE\"");
                                    }else if(score>=10){   
                                            score = score + 2;
                                            System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS BELOW AVERAGE\"");
                                    }else{
                                        System.err.println("your total score = "+score+"\n\t\"YOU NEED TO RE-APPEAR THE TEST\"");
                                    }
                            
                            System.exit(0);
                        } else {
                            System.err.println("YOU PRESS WRONG KEY:");
                        }
                    break;
                    case "no":
                        
                        int a=1;
                        while (a<5) {                            
                        System.err.println("SELECT ANY ONE:\n\tPRESS 1.APPTITUDE  \n\tPRESS 2.ENGLISH \n\tPRESS 3.MATHS  \n\tPRESS 4.GK");

                        
                        attempt= sc.nextInt();
                        switch(attempt){
                            case 1:
                                System.err.println("1. APPTITUDE\n");
                                System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 5 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.err.println("YOUR TEST HAS BEEN COMPLETE.");
                        
                                System.out.println("NOW, YOU CHECK YOUR RESULT OR CONTINUE WITH ANOTHER SUBJECT \n \t PRESS A, FOR CONTINUE \t PRESS 0, FOR EXIT");
                                attempt =sc.nextInt();
                                if (attempt==0) {

                                    if(score>=40){
                                            score = score + 10;
                                            System.err.println("your total score = "+score+"\n\t\"YOU ARE A GENIUS\"");
                                    }else if(score>=30){   
                                            score = score + 8;
                                            System.err.println("your total score = "+score+"\n\t\"YOU ARE INTELLIGENT\"");
                                    }else if(score>=20){   
                                            score = score + 5;
                                            System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS AVERAGE\"");
                                    }else if(score>=10){   
                                            score = score + 2;
                                            System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS BELOW AVERAGE\"");
                                    }else{
                                        System.err.println("your total score = "+score+"\n\t\"YOU NEED TO RE-APPEAR THE TEST\"");
                                    }

                                    System.exit(0);
                                } else if(attempt==a){
                                    a++;
                                }
                            break;
                            case 2:
                                System.err.println("2. ENGLISH\n");
                                System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 5 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.err.println("YOUR TEST HAS BEEN COMPLETE.");
                        
                                System.out.println("NOW, PRESS 0. FOR EXIT & GETS YOUR RESULT");
                                attempt =sc.nextInt();
                                if (attempt==0) {

                                    if(score>=40){
                                            score = score + 10;
                                            System.err.println("your total score = "+score+"\n\t\"YOU ARE A GENIUS\"");
                                    }else if(score>=30){   
                                            score = score + 8;
                                            System.err.println("your total score = "+score+"\n\t\"YOU ARE INTELLIGENT\"");
                                    }else if(score>=20){   
                                            score = score + 5;
                                            System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS AVERAGE\"");
                                    }else if(score>=10){   
                                            score = score + 2;
                                            System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS BELOW AVERAGE\"");
                                    }else{
                                        System.err.println("your total score = "+score+"\n\t\"YOU NEED TO RE-APPEAR THE TEST\"");
                                    }

                                    System.exit(0);
                                } else {
                                    System.err.println("YOU PRESS WRONG KEY:");
                                }
                            break;
                            case 3:
                                System.err.println("3. MATHS\n");
                                System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 5 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.err.println("YOUR TEST HAS BEEN COMPLETE.");
                        
                                System.out.println("NOW, PRESS 0. FOR EXIT & GETS YOUR RESULT");
                                attempt =sc.nextInt();
                                if (attempt==0) {

                                    if(score>=40){
                                            score = score + 10;
                                            System.err.println("your total score = "+score+"\n\t\"YOU ARE A GENIUS\"");
                                    }else if(score>=30){   
                                            score = score + 8;
                                            System.err.println("your total score = "+score+"\n\t\"YOU ARE INTELLIGENT\"");
                                    }else if(score>=20){   
                                            score = score + 5;
                                            System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS AVERAGE\"");
                                    }else if(score>=10){   
                                            score = score + 2;
                                            System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS BELOW AVERAGE\"");
                                    }else{
                                        System.err.println("your total score = "+score+"\n\t\"YOU NEED TO RE-APPEAR THE TEST\"");
                                    }

                                    System.exit(0);
                                } else {
                                    System.err.println("YOU PRESS WRONG KEY:");
                                }
                            break;
                            case 4:
                                System.err.println("4. GK\n");
                                System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.out.println("question 5 \n \t (1).TRUE \t (2).FALSE");
                                ans = sc.nextInt();
                                if (ans==1) {
                                    score = score + 8;
                                } else {
                                    score = score + 0;
                                }
                                System.err.println("YOUR TEST HAS BEEN COMPLETE.");
                        
                                System.out.println("NOW, PRESS 0. FOR EXIT & GETS YOUR RESULT");
                                attempt =sc.nextInt();
                                if (attempt==0) {

                                    if(score>=40){
                                            score = score + 10;
                                            System.err.println("your total score = "+score+"\n\t\"YOU ARE A GENIUS\"");
                                    }else if(score>=30){   
                                            score = score + 8;
                                            System.err.println("your total score = "+score+"\n\t\"YOU ARE INTELLIGENT\"");
                                    }else if(score>=20){   
                                            score = score + 5;
                                            System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS AVERAGE\"");
                                    }else if(score>=10){   
                                            score = score + 2;
                                            System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS BELOW AVERAGE\"");
                                    }else{
                                        System.err.println("your total score = "+score+"\n\t\"YOU NEED TO RE-APPEAR THE TEST\"");
                                    }

                                    System.exit(0);
                                } else {
                                    System.err.println("YOU PRESS WRONG KEY:");
                                }
                            break;
                        }
                        a++;
                        }
                    break;
                    default:
                        System.out.println("error");
                    break;

                }
                case "0":
                    System.exit(0);
        }
}
}
