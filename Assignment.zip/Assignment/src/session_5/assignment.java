/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_5;

import java.util.Scanner;
import jdk.nashorn.internal.ir.BreakNode;

/**
 *
 * @author abbasi
 */
public class assignment {
    public static void main(String[] s5) {
        int select,ans,score=0,exit,a=0;
        String attempt;
        Scanner sc = new Scanner(System.in);
        
        
        System.out.println("WELCOME TO HOWELL UNIVERSITY FOR IQ TEST");
        System.err.println("WE HAVE FOUR KIND OF TEST FOR IQ:\t 1. APPTITUDE \t 2.ENGLISH \t 3. MATHS \t 4.GK");
        System.out.println("PRESS 1.CONTINUE & PRESS 0.EXIT");
        exit =sc.nextInt();
        switch (exit){
            case 1:
                
                System.err.println("YOU ATTEMPT THIS TEST IN PAST: \"YES\" OR \"NO\"");
                attempt = sc.next();
                switch(attempt){
                    case "yes":
                        System.err.println("SORRY, YOU CAN NOT ATTEMPT THIS TEST AFTER ONE'S");
                        System.exit(0);
                        break;
                    case "no":
                        while (a<4) {
                            System.err.println("SELECT ANY ONE SUBJECT:\n\tPRESS 1.APPTITUDE  \n\tPRESS 2.ENGLISH \n\tPRESS 3.MATHS  \n\tPRESS 4.GK");

                            select= sc.nextInt();
                            switch(select){
                                case 1:
                                    System.err.println("1. APPTITUDE\n");
                                    System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }

                                    System.err.println("YOUR TEST HAS BEEN COMPLETE.");

                                    System.out.println("NOW, PRESS 0, FOR EXIT & CHECK YOUR RESULT, \nPRESS 1,IF YOU CONTINUE WITH ANOTHER SUBJECT  ");
                                    select =sc.nextInt();
                                    if (select==0) {
                                        if (score>40) {
                                            score = score/a;
                                        }

                                        if(score>=40){
                                                score = score + 10;
                                                System.err.println("your total score = "+score+"\n\t\"YOU ARE A GENIUS\"");
                                        }else if(score>=30){   
                                                score = score + 5;
                                                System.err.println("your total score = "+score+"\n\t\"YOU ARE INTELLIGENT\"");
                                        }else if(score>=20){   
                                                score = score + 2;
                                                System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS AVERAGE\"");
                                        }else if(score>=10){   
                                                score = score + 0;
                                                System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS BELOW AVERAGE\"");
                                        }else{
                                            System.err.println("your total score = "+score+"\n\t\"YOU NEED TO RE-APPEAR THE TEST\"");
                                        }

                                        System.exit(0);
                                    } else if(select==1){
                                        a++;
                                    }
                                break;
                                case 2:
                                    System.err.println("2. ENGLISH\n");
                                    System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }

                                    System.err.println("YOUR TEST HAS BEEN COMPLETE.");

                                    System.out.println("NOW, PRESS 0, FOR EXIT & CHECK YOUR RESULT, \nPRESS 1,IF YOU CONTINUE WITH ANOTHER SUBJECT  ");
                                    select =sc.nextInt();
                                    if (select==0) {
                                        if (score>40) {
                                            score = score/a;
                                        }
                                        if(score>=40){
                                                score = score + 10;
                                                System.err.println("your total score = "+score+"\n\t\"YOU ARE A GENIUS\"");
                                        }else if(score>=30){   
                                                score = score + 5;
                                                System.err.println("your total score = "+score+"\n\t\"YOU ARE INTELLIGENT\"");
                                        }else if(score>=20){   
                                                score = score + 2;
                                                System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS AVERAGE\"");
                                        }else if(score>=10){   
                                                score = score + 0;
                                                System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS BELOW AVERAGE\"");
                                        }else{
                                            System.err.println("your total score = "+score+"\n\t\"YOU NEED TO RE-APPEAR THE TEST\"");
                                        }

                                        System.exit(0);
                                    } else {

                                    }
                                break;
                                case 3:
                                    System.err.println("3. MATHS\n");

                                    System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }

                                    System.err.println("YOUR TEST HAS BEEN COMPLETE.");

                                    System.out.println("NOW, PRESS 0, FOR EXIT & CHECK YOUR RESULT, \nPRESS 1,IF YOU CONTINUE WITH ANOTHER SUBJECT  ");
                                    select =sc.nextInt();
                                    if (select==0) {
                                        if (score>40) {
                                            score = score/a;
                                        }
                                        if(score>=40){
                                                score = score + 10;
                                                System.err.println("your total score = "+score+"\n\t\"YOU ARE A GENIUS\"");
                                        }else if(score>=30){   
                                                score = score + 5;
                                                System.err.println("your total score = "+score+"\n\t\"YOU ARE INTELLIGENT\"");
                                        }else if(score>=20){   
                                                score = score + 2;
                                                System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS AVERAGE\"");
                                        }else if(score>=10){   
                                                score = score + 0;
                                                System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS BELOW AVERAGE\"");
                                        }else{
                                            System.err.println("your total score = "+score+"\n\t\"YOU NEED TO RE-APPEAR THE TEST\"");
                                        }

                                        System.exit(0);
                                    } else {

                                    }
                                break;
                                case 4:
                                    System.err.println("4. GK\n");

                                    System.out.println("question 1. \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 2 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 3 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }
                                    System.out.println("question 4 \n \t (1).TRUE \t (2).FALSE");
                                    ans = sc.nextInt();
                                    if (ans==1) {
                                        score = score + 10;
                                    } else {
                                        score = score + 0;
                                    }

                                    System.err.println("YOUR TEST HAS BEEN COMPLETE.");

                                    System.out.println("NOW, PRESS 0, FOR EXIT & CHECK YOUR RESULT, \nPRESS 1,IF YOU CONTINUE WITH ANOTHER SUBJECT  ");
                                    select =sc.nextInt();
                                    if (select==0) {
                                        if (score>40) {
                                            score = score/a;
                                        }
                                        if(score>=40){
                                                score = score + 10;
                                                System.err.println("your total score = "+score+"\n\t\"YOU ARE A GENIUS\"");
                                        }else if(score>=30){   
                                                score = score + 8;
                                                System.err.println("your total score = "+score+"\n\t\"YOU ARE INTELLIGENT\"");
                                        }else if(score>=20){   
                                                score = score + 5;
                                                System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS AVERAGE\"");
                                        }else if(score>=10){   
                                                score = score + 2;
                                                System.err.println("your total score = "+score+"\n\t\"YOUR IQ LEVEL IS BELOW AVERAGE\"");
                                        }else{
                                            System.err.println("your total score = "+score+"\n\t\"YOU NEED TO RE-APPEAR THE TEST\"");
                                        }

                                        System.exit(0);
                                    } else {

                                    }
                                break;
                                default:
                                    System.out.println("you press wrong button");
                                    a++;
                                    break;
                            }
                        }
                    break;
                    default: 
                        System.out.println("you press wrong button");
                        break;
                    
                }
                
                break;
                default:
                    System.out.println("error");
                break;
        
        
            case 0:
                System.exit(0);
        }
        }
}

