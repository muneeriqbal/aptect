/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example_session7;

/**
 *
 * @author abbasi
 */
public class example3_for_loop {
 /**
  * argument     ...
  * 
  * this three dot is a argument  
  * for same data types values. this use like a array.
  * 
  *
  * @param num
  */
    public void addNumber(int...num) {
        
        int sum=0;
        
        for(int i:num) {
            
            sum = sum + i;
            System.out.println("Sum of numbers is ="+ sum);
        }

        System.out.println("Sum of numbers is "+ sum);
    }

    public static void main(String[] args) {

        example3_for_loop obj = new example3_for_loop();
        
        obj.addNumber(2,5,1,5,3);
    }
    
}
