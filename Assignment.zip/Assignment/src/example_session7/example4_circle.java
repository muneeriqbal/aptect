/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example_session7;

import java.util.Scanner;



/**
 *
 * @author abbasi
 */
public class example4_circle {

    
    
    private double PI=3.14;
        
    public double calcArea(double rad){
        
        return (PI * rad * rad);
        
}
    
    public static void main(String[] args) {
        
        Scanner sc = new java.util.Scanner(System.in);
        System.out.println("Enter a no of radius of circle");
        int rad = sc.nextInt();
        
        example4_circle obj = new example4_circle();
        
        double a = obj.calcArea(rad);
        
        System.out.println("circle area is = " + a);
    }
}
