/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_7;

/**
 *
 * @author abbasi
 */
public class example {
 
    public void setVal(int num1) {
        num1 = num1 + 10;
        System.out.println("Value of num1 after invoking setVal is "+ num1);
    }

    public static void main(String[] args) {
    // Declare and initialize a local variable
        // Instantiate the PassByValue class
        example obj = new example();
        // Invoke the setVal() method with num1 as parameter
        obj.setVal(1);
        // Print num1 to check its value
        
}
}

