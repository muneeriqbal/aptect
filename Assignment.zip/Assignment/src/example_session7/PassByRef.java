/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example_session7;

/**
 *
 * @author abbasi
 */
public class PassByRef {
  
    public void calcArea(example2 objPi, double rad){
       
        double area= objPi.getPI() * rad * rad;
        
        System.out.println("Area of the circle is "+ area); 
    }
    
    public static void main(String[] args){

        PassByRef p1 = new PassByRef();
        
        p1.calcArea(new example2(), 3);
    }
}
