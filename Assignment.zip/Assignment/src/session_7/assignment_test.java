/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_7;

import java.util.Scanner;

/**
 *
 * @author abbasi
 */
public class assignment_test {
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
               
        
        assignment_login obj = new assignment_login();       
        obj.setUser("www", "123", "CEO");  
        
        Scanner sc = new Scanner(System.in);        
        System.out.println("name");
        String username =sc.next();     
        System.out.println("pass");
        String userpassword =sc.next(); 
        
        obj.validate(username, userpassword);
        
        
        obj.update(username, userpassword);
        
        System.out.println("new name");
        String newusername =sc.next();     
        System.out.println("new pass");
        String newuserpassword =sc.next(); 
        
        obj.validate(newusername, newuserpassword);
         
        
    }
    
}
