/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_7;

import java.util.Scanner;

/**
 *
 * @author abbasi
 */
public class assignment_login {
   
    Scanner sc = new Scanner(System.in);
    
    private String username ;
    private String password;
    private String designation;
   
   
    public void setUser(String setuser,String setpass,String setdesign){   
        username = setuser ; 
        password = setpass ;
        designation = setdesign;       
    }

    public void validate(String user,String pass){ 
        if(user.equals(username) && pass.equals(password)){
            System.err.println("Welcome " + user);
        }
        else{
            System.err.println("Invalid");
        }
    }
    
    void update(String u,String p){      
        if (u.equals(username) && p.equals(password)) {          
            System.out.println("want to update your name & password: \n \t press \"1\" \t otherwise 0");
            int a = sc.nextInt();
            switch(a){
                case 1:
                    System.out.println("enter new UserName");
                    String newName = sc.next();
                    username = newName ;
                    
                    System.out.println("enter new password");
                    String newPassword = sc.next();
                    password = newPassword;
                    break;
                case 0:
                    System.out.println("OK");
                    System.exit(0);
                    break;
                default:
                    System.err.println("Ok"); 
                    System.exit(0);            
            }           
        } else {
            System.exit(0);
        }
    }  
}
