/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_4;

import java.util.Scanner;

/**
 *
 * @author abbasi
 */
public class assignment {
        public static void main(String[] args) {
        
        Scanner input= new Scanner(System.in);
        
        int emp;
        float net_amount,add,pkg;
        String grade,bonus,shift;
        
        System.err.println("Enter your emplyoment status: \n \t press 1: for permenant. \n \t press 2: for temparary. ");
        emp = input.nextInt();
        if(emp == 1){
            System.err.println("Ente your shift: \n \t Day or Night");
            shift = input.next();
            if("day".equals(shift)){ 
                System.err.println("Today: how many package you delivered.");
                pkg = input.nextInt();
                pkg= pkg * 50+ 75;
                System.out.println(" Today you earned " + pkg);
                
                     
                System.err.println("Give bonus:\n \t  YES or NO");
                bonus = input.next();
                if("yes".equals(bonus)){
                    System.err.println("There are three categories of bonus:\n \t A for 15% \n \t B for 10% \n \t C for 5%");
                    grade = input.next();
                    switch(grade){
                        case "a":
                            net_amount = pkg*15/100 + pkg;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        case "b":
                            net_amount = pkg*10/100 + pkg;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        case "c":
                            net_amount = pkg*5/100 + pkg;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        default:
                            System.out.println("invalid grade");
                            System.out.println("your net amount is "+ pkg);
                            break;
                    }
                }   
                else{
                    System.err.println("your net amount is "+ pkg);
                    }
            }
            else if("night".equals(shift)){
                System.err.println("Tonight: how many package you delivered.");
                pkg = input.nextInt();
                pkg= pkg * 50 + 75 ;
                add= pkg*10/100 + pkg;
                System.out.println(" Tonight you earned " + add);

                
                System.err.println("Give bonus:\n \t  YES or NO");
                bonus = input.next();
                if("yes".equals(bonus)){
                    System.err.println("There are three categories of bonus:\n \t A for 15% \n \t B for 10% \n \t C for 5%");
                    grade = input.next();
                    switch(grade){
                        case "a":
                            net_amount = add*15/100 + add;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        case "b":
                            net_amount = add*10/100 + add;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        case "c":
                            net_amount = add*5/100 + add;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        default:
                            System.out.println("invalid grade");
                             System.out.println("your net amount is "+ add);
                            break;
                    }
                } 
                else{
                    System.err.println("your net amount is "+ add);
                    }
            }       
        } 
        else if(emp == 2){
            System.err.println("Ente your shift: \n \t Day or Night");
            shift = input.next();
            if("day".equals(shift)){ 
                System.err.println("Today: how many package you delivered.");
                pkg = input.nextInt();
                pkg= pkg * 30+ 65;
                System.out.println(" Today: you earned " + pkg);

                
                System.err.println("Give bonus:\n \t  YES or NO");
                bonus = input.next();
                if("yes".equals(bonus)){
                    System.out.println("There are three categories of bonus:\n \t A for 15% \n \t B for 10% \n \t C for 5%");
                    grade = input.next();
                    switch(grade){
                        case "A1":
                            net_amount = pkg*15/100 + pkg;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        case "A2":
                            net_amount = pkg*10/100 + pkg;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        case "A3":
                            net_amount = pkg*5/100 + pkg;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        default:
                            System.out.println("invalid grade");
                             System.out.println("your net amount is "+ pkg);
                            break;
                    }
                }
                else{
                    System.err.println("your net amount is "+ pkg);
                    }
            }
            else if("night".equals(shift)){
                System.out.println("Tonight: how many package you delivered.");
                pkg = input.nextInt();
                pkg= pkg * 30+ 65 ;
                add= pkg*10/100 + pkg ;
                System.out.println(" Tonight you earned " + add);
                     
                
                System.out.println("Give bonus:\n \t  YES or NO");
                bonus = input.next();
                if("yes".equals(bonus)){
                    System.out.println("There are three categories of bonus:\n \t A for 15% \n \t B for 10% \n \t C for 5%");
                    grade = input.next();
                    switch(grade){
                        case "a":
                            net_amount = add*15/100 + add;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        case "b":
                            net_amount = add*10/100 + add;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        case "c":
                            net_amount = add*5/100 + add;
                            System.out.println("your net amount is "+net_amount);
                            break;
                        default:
                            System.out.println("invalid grade");
                             System.out.println("your net amount is "+ add);
                            break;
                    }
                } 
                else{
                    System.err.println("your net amount is "+ add);
                    }
            }       
        }else{
            System.out.println("invalid");
        }   
    }
    
}
