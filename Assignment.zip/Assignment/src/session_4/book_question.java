/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session_4;

import java.util.Scanner;

/**
 *
 * @author abbasi
 */
public class book_question {
    
    public static void main(String[] bq){

        /// question 1
        
        int age,asset,prof;
        String gender;
        
        Scanner user = new Scanner(System.in);
        
        System.err.println("enter your age");
        
        age =user.nextInt();
        
//first if

        if (age > 15 && age < 26) {
            
            System.out.println(" YOUR AGE IS "+ age);
            System.err.println("\n enter your gender");
            
            gender= user.next();
            
            System.out.println("YOUR GENDER IS "+ gender);
            System.err.println("\n enter personal asset");
            
            asset = user.nextInt();
//second if            
            if (asset >= 25000) {
                
                System.out.println("YOUR PERSONAL ASSETS IS "+asset);
                System.err.println("\n enter your profession");
                System.err.println(" "+" "+" "+"slect any profession \n 1 for self-emplyee \n 2 for professional");
                
                prof = user.nextInt();
//third if         
                if(prof == 1){     
                    System.err.println(" you can get 10000 rupees loan ");
                    
                } else if(prof == 2){
                    System.err.println(" you can get 15000 rupees loan");
//third else                
                } else {      
                    System.err.println("please select only between 1 & 2");
                }                
            }
//second else            
            else{  
                System.err.println("sorry You are  eligable");
            }
        }
// first else if        
        else if (age >25 && age <41) {
             
            System.out.println("YOUR AGE IS "+ age);
            
            System.err.println("\n enter your gender");
            
            gender= user.next();
//second if           
            if ("male".equals(gender)) {
                 System.out.println("YOUR GENDER IS "+ gender);
                 System.err.println("\n enter personal asset");
            
            asset = user.nextInt();
// third if            
                if (asset >= 40000) {
                
                System.out.println("YOUR PERSONAL ASSETS IS "+asset);
                System.err.println("\n enter your profession");
                System.err.println(" "+" "+" "+"slect any profession \n 1 for self-emplyee \n 2 for professional");
                
                prof = user.nextInt();
// fourth if          
                    if(prof == 1 || prof == 2){     
                         System.err.println(" you can get 25000 rupees loan ");
                    }
//fourth else                     
                    else {      
                       System.err.println("please select only between 1 & 2");
                     }
//third else                     
                }else{  
                    System.err.println("sorry You are  eligable");
                }
            }
//second else if            
            else if("female".equals(gender)) {
                    System.out.println("YOUR GENDER IS "+ gender);
                    System.err.println("\n enter personal asset");
            
                    asset = user.nextInt();
//third if            
                    if (asset >= 40000) {
                
                        System.out.println("YOUR PERSONAL ASSETS IS "+asset);
                        System.err.println("\n enter your profession");
                        System.err.println(" "+" "+" "+"slect any profession \n 1 for self-emplyee \n 2 for professional");
                
                        prof = user.nextInt();
//fourth if          
                        if(prof == 1 || prof == 2){     
                            System.err.println(" you can get 30000 rupees loan ");                    
                        } 
// fouth else                        
                        else {      
                            System.err.println("please select only between 1 & 2");
                        }
                    }
//third else                    
                    else{  
                        System.err.println("sorry You are  eligable");
                    }
            }
//second  else   
            else{
                System.err.println("sorry You are  eligable");
            }
        }
//third else if
        else if (age >41 && age <61) {
          
            System.out.println(" YOUR AGE IS "+ age);
            System.err.println("\n enter your gender");
            
            gender= user.next();
            
            System.out.println("YOUR GENDER IS "+ gender);
            System.err.println("\n enter personal asset");
            
            asset = user.nextInt();
//second if            
            if (asset >= 50000) {
                
                System.out.println("YOUR PERSONAL ASSETS IS "+asset);
                System.err.println("enter your profession");
                System.err.println("slect any profession \n 1 for self-emplyee \n 2 for professional");
                
                prof = user.nextInt();
//third if          
                if(prof == 1 || prof == 2){     
                    System.err.println(" you can get 40000 rupees loan ");
                }
//third else                
                else {      
                    System.err.println("please select only between 1 & 2");
                }
            }
//second else            
            else{  
                System.err.println("sorry You are  eligable");
            }   
        }
//fourth else if        
        else if (age >60) {
        
            System.out.println(" YOUR AGE IS "+ age);
            System.err.println("\n enter your gender");
            
            gender= user.next();
            
            System.out.println("YOUR GENDER IS "+ gender);
            System.err.println("\n enter personal asset");
            
            asset = user.nextInt();
//second if            
            if (asset >= 25000) {
                
                System.out.println("YOUR PERSONAL ASSETS IS "+asset);
                System.err.println("enter your profession");
                System.err.println("slect any profession \n 1 for self-emplyee \n 2 for retired");
                
                prof = user.nextInt();
//third if          
                if(prof == 1){   
                    int abc = 35000 - age * 100;
                   System.out.println(" you can get " + abc +" rupees loan ");
                } 
                else if(prof == 2){
                    int ret = 25000- age * 100;
                    System.out.println(" you can get " + ret + " rupees loan");
                }
//third else               
                else {      
                    System.err.println("please select only between 1 & 2");
                }
            }
//second else           
            else{  
                System.err.println("sorry You are  eligable");
            }
        }
        else{
            System.err.println("sorry You are  eligable");
        }

        
        
//        question 2 = vowel or not
//        
//        Scanner sc = new Scanner(System.in);
//        
//        System.out.println("Enter The Alphabet...");
//        
//        String vowel =sc.next();
//        
//        switch(vowel){
//        
//            case "a":
//            case "A":
//            case "e":
//            case "E":
//            case "i":
//            case "I":
//            case "o":
//            case "O":
//            case "u":
//            case "U":
//                System.out.println(vowel+" is vowl");
//                break;
//            default:
//                System.out.println(vowel+" is not vowel");
//                break;
//        }
    

        
        
        
        
        
//        question 3 = interest earned
//    
//        Scanner sc =new Scanner(System.in);
//        
//        System.out.println("Enter the deposit amount");
//        
//        int amount = sc.nextInt();
//        
//        
//        if (amount<=2000) {
//            
//            float earn = amount/100*4;
//            
//            System.out.println("interest earned is "+earn+"rs");
//        }else if (amount<=7000) {
//            
//            float earn = (float) (amount/100*4.5);
//            
//            System.out.println("interest earned is "+earn+"rs");
//
//        } else if (amount>7000) {
//            
//            float earn = amount/100*5;
//            
//            System.out.println("interest earned is "+earn+"rs");
//
//        }else{
//            System.out.println("Something Wrong");
//        }
//        
//        
//        
    }  
    
    
}
