/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class calculator {

    /**
     * @param args the command line arguments
     */
    public void add(int num1, int num2) {
       
        int num3;
        num3 = num1 + num2;
        
        System.out.println("number after adding = "+ num3);
    } 
    
    public void sub(int num1, int num2) {
       
        int num3;
        num3 = num1 - num2;
        
        System.out.println("number after substraction = "+ num3);   
    }
    
    public void mul(int num1, int num2) {
       
        int num3;
        num3 = num1 * num2;
        
        System.out.println("number after multplication = "+ num3);   
    }
    
    public void div(int num1, int num2) {
       
        int num3;
        num3 = num1 / num2;
        
        System.out.println("number after division = "+ num3);   
    }
    
    public static void main(String[] args) {
        
        calculator objcal = new calculator();
        
        
        Scanner sc = new Scanner(System.in);
        System.out.println("enter 1st number");
        int num1 = sc.nextInt();
        System.out.println("enter 2nd number");
        int num2 = sc.nextInt();
        
        System.out.println("kya krna chahty ho");
       
        int a = 0;
        while (a<4) {            
            
        int optr = sc.nextInt();
        switch (optr){
            case 1:
                objcal.add(num1, num2);
                break;
            case 2:    
                objcal.mul(num1, num2);
                break;
            case 3:    
                objcal.div(num1, num2);
                break;    
            case 4:    
                objcal.sub(num1, num2);
                break; 
    
        }
        a++;
        }
    }
        
        
    
}
